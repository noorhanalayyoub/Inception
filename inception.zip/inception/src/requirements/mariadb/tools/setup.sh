#!/bin/bash
set -e

# assign values
MYSQL_PASSWORD=$(cat /run/secrets/db_password)
MYSQL_ROOT_PASSWORD=$(cat /run/secrets/db_root_password)
MYSQL_DATABASE=${MYSQL_DATABASE}
MYSQL_USER=${MYSQL_USER}

echo "THIS IS mariadb SCRIIIIIIIIIIIIPT"

# Allow remote connections
sed -i 's/^bind-address.*=.*127.0.0.1/bind-address = 0.0.0.0/' \
    /etc/mysql/mariadb.conf.d/50-server.cnf

# Step 1: Check if MariaDB has already been initialized
if [ ! -d /var/lib/mysql/mysql ]; then
  echo "No existing database found. Initializing MariaDB..."

  # initialize the data directory (modern command)
  mariadb-install-db --user=mysql --basedir=/usr --datadir=/var/lib/mysql
  echo "db was installed"

  # start mariadb in bootstrap mode to setup users and DB
  mysqld --bootstrap --user=mysql <<EOF
        CREATE DATABASE IF NOT EXISTS \`${MYSQL_DATABASE}\`;

        -- Create root user with full access (both localhost and any host)
        ALTER USER 'root'@'localhost' IDENTIFIED BY '${MYSQL_ROOT_PASSWORD}';

        -- Create application user for both localhost and remote connections
        CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'localhost' IDENTIFIED BY '${MYSQL_PASSWORD}';
        CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'%' IDENTIFIED BY '${MYSQL_PASSWORD}';

        GRANT ALL PRIVILEGES ON \`${MYSQL_DATABASE}\`.* TO '${MYSQL_USER}'@'localhost';
        GRANT ALL PRIVILEGES ON \`${MYSQL_DATABASE}\`.* TO '${MYSQL_USER}'@'%';

        -- Remove anonymous users for security
        DELETE FROM mysql.user WHERE User='';
        DELETE FROM mysql.user WHERE User='root' AND Host NOT IN ('localhost', '127.0.0.1', '::1');

        FLUSH PRIVILEGES;
EOF
  echo "Database and users configured"
fi

echo "Starting MariaDB server..."

chown -R mysql:mysql /var/lib/mysql

exec mysqld --user=mysql
